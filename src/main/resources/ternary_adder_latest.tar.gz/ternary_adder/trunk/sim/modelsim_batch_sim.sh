#!/bin/bash
vsim -c -do 'do batch_sim.do'
